CREATE VIEW act_id_user AS
  SELECT
    `u`.`id`         AS `ID_`,
    `u`.`version`    AS `REV_`,
    `u`.`name`       AS `FIRST_`,
    `u`.`login_name` AS `LAST_`,
    `u`.`email`      AS `EMAIL_`,
    `u`.`password`   AS `PWD_`,
    NULL             AS `PICTURE_ID_`
  FROM `admineap`.`tbl_user` `u`;

