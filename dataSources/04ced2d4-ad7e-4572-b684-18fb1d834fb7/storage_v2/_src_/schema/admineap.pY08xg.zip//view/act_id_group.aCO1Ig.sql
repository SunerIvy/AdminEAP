CREATE VIEW act_id_group AS
  SELECT
    `admineap`.`tbl_role`.`id`      AS `ID_`,
    `admineap`.`tbl_role`.`version` AS `REV_`,
    `admineap`.`tbl_role`.`name`    AS `NAME_`,
    `admineap`.`tbl_role`.`code`    AS `TYPE_`
  FROM `admineap`.`tbl_role`;

