CREATE VIEW act_id_membership AS
  SELECT
    `admineap`.`tbl_user_role`.`userId` AS `USER_ID_`,
    `admineap`.`tbl_user_role`.`roleId` AS `GROUP_ID_`
  FROM `admineap`.`tbl_user_role`;

