CREATE VIEW v_crs_schemerelateditems as 
select t_crs_schemes.fd_scheme_id 		        as fd_scheme_id,
       t_crs_schemeanditemrelations.fd_item_id 		as fd_item_id,
       t_crs_schemeanditemrelations.fd_item_index 	as fd_item_index,
       t_crs_schemeanditemrelations.fd_skipped 		as fd_skipped,  
       t_crs_schemeanditemrelations.fd_manuconfirmed 	as fd_manuconfirmed, 
       t_crs_schemeanditemrelations.fd_waitconfirm_time as fd_waitconfirm_time,
       t_crs_schemeanditemrelations.fd_timeout_execed 	as fd_timeout_execed,
       t_crs_schemeitems.fd_execute_time as fd_execute_time
from   t_crs_schemes, t_crs_schemeanditemrelations, t_crs_schemeitems 
where  t_crs_schemes.fd_scheme_id = t_crs_schemeanditemrelations.fd_scheme_id
and    t_crs_schemeanditemrelations.fd_item_id = t_crs_schemeitems.fd_item_id;

